package com.mojang.blaze3d.buffers;

import com.mojang.blaze3d.DontObfuscate;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
@DontObfuscate
public record GpuBufferSlice(GpuBuffer buffer, int offset, int length) {
    public GpuBufferSlice slice(int p_418188_, int p_418476_) {
        if (p_418188_ >= 0 && p_418476_ >= 0 && p_418188_ + p_418476_ < this.length) {
            return new GpuBufferSlice(this.buffer, this.offset + p_418188_, p_418476_);
        } else {
            throw new IllegalArgumentException(
                "Offset of "
                    + p_418188_
                    + " and length "
                    + p_418476_
                    + " would put new slice outside existing slice's range (of "
                    + p_418188_
                    + ","
                    + p_418476_
                    + ")"
            );
        }
    }
}
